import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.*;

import com.sun.deploy.util.BlackList;
import processing.core.PImage;
import processing.core.PApplet;


public class Blacksmith extends Entity {

    public Blacksmith(String id, List<PImage> images, Point position)
    {
      super(id, images, position);

    }

}