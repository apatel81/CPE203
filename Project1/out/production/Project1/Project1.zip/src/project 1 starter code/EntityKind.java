enum EntityKind
{
   BLACKSMITH,
   MINER_FULL,
   MINER_NOT_FULL,
   OBSTACLE,
   ORE,
   ORE_BLOB,
   QUAKE,
   VEIN
}
